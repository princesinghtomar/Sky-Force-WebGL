var x = document.getElementById("glcanvas");
x.width = window.innerWidth-10;
x.height = window.innerHeight-10;
console.log(window.innerWidth)