# Graphics Assignment 2 
## Sky Force Game
- Instructions :
    - Use Live server
    - After live server open that port in browser
    - Internet connection is required since some resources are present online

> Nothing else to say :)